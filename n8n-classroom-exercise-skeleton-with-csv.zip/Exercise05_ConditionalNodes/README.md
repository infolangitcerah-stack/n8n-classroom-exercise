# ⚖️ Exercise 05 – ConditionalNodes  

📅 Created: 1 October  

### 📌 Description  
Short description of the workflow goes here.  

### 🔑 Key Nodes  
- Manual Trigger  
- Set  
- Code  

### 🖼️ Workflow Screenshot  
*(To be added later)*  
