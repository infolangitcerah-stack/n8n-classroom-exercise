# 🧪 Exercise 19 – MyWorkflow4  

📅 Created: 6 October  

### 📌 Description  
Short description of the workflow goes here.  

### 🔑 Key Nodes  
- Manual Trigger  
- Set  
- Code  

### 🖼️ Workflow Screenshot  
*(To be added later)*  
