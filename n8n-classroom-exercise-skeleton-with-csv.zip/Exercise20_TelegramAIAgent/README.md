# 💬 Exercise 20 – TelegramAIAgent  

📅 Created: 7 October  

### 📌 Description  
Short description of the workflow goes here.  

### 🔑 Key Nodes  
- Manual Trigger  
- Set  
- Code  

### 🖼️ Workflow Screenshot  
*(To be added later)*  
