# 💬 Exercise 04 – CoachDomTelegram  

📅 Created: 30 September  

### 📌 Description  
Short description of the workflow goes here.  

### 🔑 Key Nodes  
- Manual Trigger  
- Set  
- Code  

### 🖼️ Workflow Screenshot  
*(To be added later)*  
